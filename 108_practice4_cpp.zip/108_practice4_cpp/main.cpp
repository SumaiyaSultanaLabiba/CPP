#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>  // for file handling

using namespace std;

//**************** ****************************************************************** **********************/
//**************** 'Cricketer' class represents a general cricketer. Do not change!!! **********************/
//****************   You can not add any other properties or methods in any classes   **********************/
//**************** ****************************************************************** **********************/
class Cricketer {
protected:
    string name;
    int age;
    int matchPlayed;

public:
    // constructor to initialize name, age, and matches played
    Cricketer(string s = "Unknown", int a = 0, int m = 0) : name(s), age(a), matchPlayed(m) {}

    string getName() { return name; }
    int getMatchPlayed() { return matchPlayed; }
    int getAge() { return age; }
    void setName(string n) { name = n; }
    void setAge(int a) { age = a; }
    void setMatchPlayed(int m) { matchPlayed = m; }

    // Prints basic cricketer info
    virtual void printInfo(ofstream& out) {
        out << "Name: " << name << ", Age: " << age << ", Matches Played: " << matchPlayed << endl;
    }
    
    virtual ~Cricketer() {}
};

//**************** ****************************************************************** **********************/
//**************** ****************************************************************** **********************/





// 'Batsman' class represents a batsman
// Inherit 'Cricketer' class to implement 'Batsman'
class Batsman:virtual public Cricketer{
protected:
    int runScored;
    int ballsFaced;

public:
    // Implement Constructor to initialize batting details along with cricketer data
    // Take Name, Age, Matches played, Runs, Balls 
    Batsman(string name="Unknown", int age=0, int matchPlayed=0, int runScored=0, int ballsFaced=0)
    {
      this->name=name;
      this->age=age;
      this->matchPlayed=matchPlayed;
      this->ballsFaced=ballsFaced;
      this->runScored=runScored;
    }


    // Compute batting average: runs/matches
    double computeBattingAverage()
    {
        return (double)this->runScored/(double)this->matchPlayed;
    }

    // Compute strike rate: (runs/balls faced) * 100
    double computeStrikeRate()
    {
        return ((double)this->runScored/(double)this->ballsFaced)*100;
    }

    // Getter & Setter for total runs
    void set_runScored(int runScored) {this->runScored=runScored;}
    int get_runScored() {return this->runScored;}

    // Getter & Setter for balls faced
    void set_ballsFaced(int ballsFaced) {this->ballsFaced=ballsFaced;}
    int get_ballsFaced() {return this->ballsFaced;}

    // Print batsman-specific stats; you have to use the base class's method here.
    void printInfo(ofstream& outputFile) override
    {
      outputFile<<"---- Batsman Info ----"<<endl;  
      Cricketer::printInfo(outputFile);
      outputFile<<"---- Batting Stats ----"<<endl;
      outputFile<<"Runs Scored: "<<this->runScored<<", Balls Faced: "<<this->ballsFaced<<endl;
      outputFile<<fixed<<setprecision(2);
      outputFile<<"Batting Average: "<<this->computeBattingAverage()<<", Strike Rate: "<<this->computeStrikeRate()<<endl;
    }
};





// 'Bowler' class represents a bowler
// Inherit 'Cricketer' class to implement 'Bowler'
class Bowler:virtual public Cricketer {
protected:
    int wicketsTaken;
    int runsConceded;
    double oversBowled;

public:
    // Implement Constructor to initialize bowling details along with cricketer data
    // Take Name, Age, Matches played, Wickets, RunsConceded, Overs
    Bowler(string name="Unknown", int age=0, int matchPlayed=0, int wicketsTaken=0, int runsConceded=0, double oversBowled=0)
    {
      this->name=name;
      this->age=age;
      this->matchPlayed=matchPlayed;
      this->wicketsTaken=wicketsTaken;
      this->runsConceded=runsConceded;
      this->oversBowled=oversBowled;
    }

    // Compute average wickets per match
    double computeWicketAverage()
    {
      return (double)this->wicketsTaken/(double)this->matchPlayed;
    }

    // Compute economy rate: runs conceded per over
    double computeEconomy()
    {
      return (double)this->runsConceded/(double)this->oversBowled;
    }

    // Getter & Setter for wickets
    void set_wicketsTaken(int wicketsTaken) {this->wicketsTaken=wicketsTaken;}
    int get_wicketsTaken() {return this->wicketsTaken;}

    // Getter & Setter for runs conceded
    void set_runsConceded(int runsConceded) {this->runsConceded=runsConceded;}
    int get_runsConceded() {return this->runsConceded;}

    // Getter & Setter for overs bowled
    void set_oversBowled(int oversBowled) {this->oversBowled=oversBowled;}
    int get_oversBowled() {return this->oversBowled;}


    // Print bowler-specific stats; you have to use the base class's method here.
    void printInfo(ofstream& outputFile) override
    {
      outputFile<<"---- Bowler Info ----"<<endl;  
      Cricketer::printInfo(outputFile);
      outputFile<<"---- Bowling Stats ----"<<endl;
      outputFile<<"Wickets Taken: "<<this->wicketsTaken<<", Runs Conceded: "<<this->runsConceded<<", Overs Bowled: "<<this->oversBowled<<endl;
      outputFile<<fixed<<setprecision(2);
      outputFile<<"Wicket Average: "<<this->computeWicketAverage()<<", Economy: "<<this->computeEconomy()<<endl;
    }
};



// The following class represents an allrounder (inherits from both Batsman and Bowler)
class Allrounder:public Batsman, public Bowler {
public:
    // Implement Constructor to initialize all data for an allrounder (batsman and bowler)
    Allrounder(string name="Unknown", int age=0, int matchPlayed=0, int runScored=0, int ballsFaced=0, int wicketsTaken=0, int runsConceded=0, double oversBowled=0)
    {
        this->name=name;
        this->age=age;
        this->matchPlayed=matchPlayed;
        this->runScored=runScored;
        this->ballsFaced=ballsFaced;
        this->wicketsTaken=wicketsTaken;
        this->runsConceded=runsConceded;
        this->oversBowled=oversBowled;
    }

    // Print both batting and bowling statistics; you have to use the base class's method here.
    void printInfo(ofstream& outputFile) override
    {
      outputFile<<"---- Allrounder Info ----"<<endl;  
      Cricketer::printInfo(outputFile);
      outputFile<<"---- Batting Stats ----"<<endl;
      outputFile<<"Runs Scored: "<<this->runScored<<", Balls Faced: "<<this->ballsFaced<<endl;
      outputFile<<fixed<<setprecision(2);
      outputFile<<"Batting Average: "<<this->computeBattingAverage()<<", Strike Rate: "<<this->computeStrikeRate()<<endl;
      outputFile<<"---- Bowling Stats ----"<<endl;
      outputFile<<"Wickets Taken: "<<this->wicketsTaken<<", Runs Conceded: "<<this->runsConceded<<", Overs Bowled: "<<this->oversBowled<<endl;
      outputFile<<"Wicket Average: "<<this->computeWicketAverage()<<", Economy: "<<this->computeEconomy()<<endl;
    }
};



// input file style
// TYPE Name Age Matches Runs Balls Wickets RunsConceded Overs

int main() {
    // You have to take input from "input1.txt" and you have to generate an "output.txt" file like "Demo_output.txt"
    // First take the players information from "input.txt" and create necessary player objects 
    // Then save them in an array of players
    // Finally, show the players' information 
    // NOTE: Players can be of any type
    ifstream inputFile("input1.txt");
    ofstream outputFile("output1.txt");
    Cricketer* player[7];
    
    for(int i=0; i<7; i++)
    {
        string type;
        inputFile>>type;

        if(type=="Batsman")
        {
           string name;
           int age;
           int matchPlayed;
           int runScored;
           int ballsFaced;

           inputFile>>name;
           inputFile>>age;
           inputFile>>matchPlayed;
           inputFile>>runScored;
           inputFile>>ballsFaced;

           player[i]=new Batsman(name, age, matchPlayed, runScored, ballsFaced);
        }

        if(type=="Bowler")
        {
           string name;
           int age;
           int matchPlayed;
           int wicketsTaken;
           int runsConceded;
           double oversBowled;

           inputFile>>name;
           inputFile>>age;
           inputFile>>matchPlayed;
           inputFile>>wicketsTaken;
           inputFile>>runsConceded;
           inputFile>>oversBowled;

           player[i]=new Bowler(name, age, matchPlayed, wicketsTaken, runsConceded, oversBowled);
        }

        if(type=="Allrounder")
        {
           string name;
           int age;
           int matchPlayed;
           int runScored;
           int ballsFaced;
           int wicketsTaken;
           int runsConceded;
           double oversBowled;

           inputFile>>name;
           inputFile>>age;
           inputFile>>matchPlayed;
           inputFile>>runScored;
           inputFile>>ballsFaced;
           inputFile>>wicketsTaken;
           inputFile>>runsConceded;
           inputFile>>oversBowled;

           player[i]=new Allrounder(name, age, matchPlayed, runScored, ballsFaced, wicketsTaken, runsConceded, oversBowled);
        }
    }

    for(int i=0; i<7; i++)
    {
        outputFile<<"=== Player "<<(i+1)<<" ==="<<endl;
        player[i]->printInfo(outputFile);
        outputFile<<endl;
    }

    for(int i=0; i<7; i++)
    {
        delete player[i];
    }

    inputFile.close();
    outputFile.close();
    return 0;
}
